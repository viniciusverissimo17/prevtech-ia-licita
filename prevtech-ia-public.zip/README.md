# Prevtech-IA
Sistema com IA para geração de documentos licitatórios.