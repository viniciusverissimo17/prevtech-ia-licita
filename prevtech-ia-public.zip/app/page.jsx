export default function Home() {
  return (
    <main style={{ padding: "2rem", fontFamily: "sans-serif" }}>
      <h1>Prevtech-IA</h1>
      <p>Sistema inteligente para geração de ETP, TR e Editais.</p>
    </main>
  );
}